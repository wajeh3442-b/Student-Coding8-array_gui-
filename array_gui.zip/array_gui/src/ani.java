import javax.swing.*;
import java.awt.*;

public class ani extends JFrame {

    public ani() {
        setTitle("ARRAY");
        setUndecorated(true); // Remove title bar for splash screen look


        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setSize(screenSize.width, screenSize.height);
        setLocation(0, 0); // Top-left corner
        setLayout(new BorderLayout());

        // Background color similar to ChatGPT (Dark Mode)
        getContentPane().setBackground(new Color(32, 33, 35));

        // === LOGO / IMAGE ===
        // Note: Make sure this path is correct on your computer!
        String imagePath = "C:/Users/MC/Pictures/Camera Roll/array.png";
        ImageIcon icon = new ImageIcon(imagePath);
        JLabel logo = new JLabel(icon);
        logo.setHorizontalAlignment(SwingConstants.CENTER);
        add(logo, BorderLayout.CENTER); // Center logo

        // === LOADING TEXT ===
        JLabel loadingText = new JLabel("Loading Array...");
        loadingText.setForeground(Color.WHITE);
        loadingText.setFont(new Font("Segoe UI", Font.BOLD, 24));
        loadingText.setHorizontalAlignment(SwingConstants.CENTER);
        // Add some padding at the bottom so it's not sticking to the edge
        loadingText.setBorder(BorderFactory.createEmptyBorder(0, 0, 50, 0));
        add(loadingText, BorderLayout.SOUTH);

        // === ANIMATION 1: DOTS (...) ===
        // This timer runs every 500ms to update text
        Timer textTimer = new Timer(500, e -> {
            String text = loadingText.getText();
            if (text.endsWith("...")) {
                loadingText.setText("Loading array");
            } else {
                loadingText.setText(text + ".");
            }
        });
        textTimer.start();

        // === ANIMATION 2: SWITCH TO MAIN APP ===
        // This timer runs ONCE after 3 seconds
        Timer switchTimer = new Timer(3000, e -> {
            textTimer.stop(); // Stop the text animation
            dispose();        // Close the splash screen

            // Open the Main GUI
            gui mainApp = new gui();
            mainApp.setVisible(true);
        });

        switchTimer.setRepeats(false); // CRITICAL: Run only once!
        switchTimer.start();

        setVisible(true);
    }


}