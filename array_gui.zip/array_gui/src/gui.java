import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class gui extends JFrame {
    private JTextField sizeField;
    private JButton sizeButton;
    private JPanel elementsPanel;
    private JButton showButton;
    private JPanel arrayDisplayPanel;
    private int arraySize;
    private JTextField[] elementFields;

    public gui() {
        setTitle("Array Visualizer with Index");
        setSize(700, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new FlowLayout());

        JLabel sizeLabel = new JLabel("Enter Array Size:");
        add(sizeLabel);

        sizeField = new JTextField(5);
        add(sizeField);

        sizeButton = new JButton("Set Size");
        add(sizeButton);

        elementsPanel = new JPanel();
        elementsPanel.setLayout(new GridLayout(0, 2, 5, 5));
        add(elementsPanel);

        showButton = new JButton("Show Array");
        add(showButton);

        arrayDisplayPanel = new JPanel();
        arrayDisplayPanel.setPreferredSize(new Dimension(650, 150));
        arrayDisplayPanel.setBackground(Color.WHITE);
        arrayDisplayPanel.setLayout(new GridLayout(2, 0, 10, 10)); // 2 rows: index row + value row
        add(arrayDisplayPanel);

        // Set array size and create input fields
        sizeButton.addActionListener(e -> {
            try {
                arraySize = Integer.parseInt(sizeField.getText());
                elementsPanel.removeAll();
                elementFields = new JTextField[arraySize];
                for (int i = 0; i < arraySize; i++) {
                    elementsPanel.add(new JLabel("Element " + i + ":"));
                    elementFields[i] = new JTextField(5);
                    elementsPanel.add(elementFields[i]);
                }
                elementsPanel.revalidate();
                elementsPanel.repaint();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Enter a valid number!");
            }
        });

        // Show array with index numbers
        showButton.addActionListener(e -> {
            arrayDisplayPanel.removeAll();
            try {
                JPanel indexPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
                JPanel valuePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));

                for (int i = 0; i < arraySize; i++) {
                    int value = Integer.parseInt(elementFields[i].getText());

                    // Index label
                    JLabel indexLabel = new JLabel("[" + i + "]", SwingConstants.CENTER);
                    indexLabel.setPreferredSize(new Dimension(50, 20));
                    indexPanel.add(indexLabel);

                    // Value box
                    JLabel valueLabel = new JLabel(String.valueOf(value), SwingConstants.CENTER);
                    valueLabel.setPreferredSize(new Dimension(50, 50));
                    valueLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
                    valueLabel.setOpaque(true);
                    valueLabel.setBackground(Color.CYAN);
                    valuePanel.add(valueLabel);
                }

                arrayDisplayPanel.setLayout(new GridLayout(2, 1, 5, 5));
                arrayDisplayPanel.add(indexPanel);
                arrayDisplayPanel.add(valuePanel);

                arrayDisplayPanel.revalidate();
                arrayDisplayPanel.repaint();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Enter valid integers!");
            }
        });

        setVisible(true);
    }



}
